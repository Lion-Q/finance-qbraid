###############################################################################
# // SPDX-License-Identifier: Apache-2.0
# // Copyright : JP Morgan Chase & Co
###############################################################################

from .qaoa_objective import get_qaoa_objective
from .qaoa_objective_labs import get_qaoa_labs_objective
